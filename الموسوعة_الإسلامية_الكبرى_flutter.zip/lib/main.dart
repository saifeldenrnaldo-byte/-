
import 'package:flutter/material.dart';

void main() => runApp(const IslamicEncyclopediaApp());

class IslamicEncyclopediaApp extends StatelessWidget {
  const IslamicEncyclopediaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الموسوعة الإسلامية الكبرى',
      theme: ThemeData.dark(),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final List<String> sections = const [
    "القرآن الكريم",
    "التفسير",
    "الأحاديث",
    "الأذكار",
    "الأنبياء",
    "الخلفاء الراشدون",
    "التاريخ الإسلامي",
    "الفتوحات الإسلامية",
    "مواقيت الصلاة",
    "القبلة",
    "البحث",
    "المفضلة"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("الموسوعة الإسلامية الكبرى")),
      body: Column(
        children: [
          const SizedBox(height: 12),
          const CircleAvatar(radius: 50, child: Icon(Icons.menu_book,size:50)),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              "موسوعة شاملة للقرآن الكريم والسنة النبوية والتاريخ الإسلامي",
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: sections.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
              ),
              itemBuilder: (context, i) => Card(
                child: Center(child: Text(sections[i], textAlign: TextAlign.center)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
